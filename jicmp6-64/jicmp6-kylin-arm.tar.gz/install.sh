#!/bin/bash
# 安装脚本
set -e
LIB_DIR="/usr/lib"
JAVA_DIR="/usr/share/java"

if [ ! -f "libjicmp6.so" ]; then
  echo "错误: 缺少 libjicmp6.so"
  exit 1
fi

echo "安装 libjicmp6.so 到 $LIB_DIR"
sudo install -m 0755 libjicmp6.so $LIB_DIR/

echo "安装 jicmp6.jar 到 $JAVA_DIR"
sudo install -m 0644 jicmp6.jar $JAVA_DIR/

echo "更新动态链接库缓存"
sudo ldconfig

echo "安装成功!"
